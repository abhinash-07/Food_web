import foodModel from "../Models/foodmodels.js";
import fs from 'fs';


//add food
const addFood = async (req, res) => {
    let image_name = `${req.file.filename}`;
    const food = new foodModel({ 
        name:req.body.name,
        description:req.body.description ,
        price : req.body.price,
        category: req.body.category,
        image : image_name
         });
    try {
        await food.save();
        res.status(201).json({success:true, message: "Food added successfully"});
    } catch (error) {
        console.log("Error", error);
        res.status(409).json({ message: error.message });
    }
}

//all food list
const listFood = async (req, res) => {
   
    try {
        const food = await foodModel.find({});
        res.status(200).json({success:"true" , data:food});
    } catch (error) {
        res.status(404).json({ message: error.message });
    }
}

//remove food
const removeFood = async (req, res) => {
    try {
        const food = await foodModel.findById(req.body.id);
        fs.unlink(`uploads/${food.image}`,()=>{})
        await foodModel.findByIdAndDelete(req.body.id);
        res.status(200).json({success:true, message: "Food removed successfully"})
    } catch (error) {
        res.status(404).json({ message: error.message });
        console.log("Error", error);
    }
}

export {addFood ,listFood,removeFood}

