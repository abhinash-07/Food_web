import express from "express"
import { addFood, listFood, removeFood } from "../Controllers/foodController.js";
import multer from 'multer';


const foodRouter = express.Router();
// Food Routes


const storage = multer.diskStorage({
    destination: "upload",
    filename: function(req, file, cb) {
        return cb(null, `${Date.now()}${file.originalname}`); 
    }
})

const upload = multer({ storage: storage });
foodRouter.post("/add" ,upload.single("image"), addFood);
foodRouter.get("/list",listFood);
foodRouter.post("/remove",removeFood);



export default foodRouter;
