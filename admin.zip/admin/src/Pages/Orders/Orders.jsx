import React from 'react'
import './Orders.css'

const Orders = () => {
  return (
    <div>Orders</div>
  )
}

export default Orders