import express from "express";

import cors from "cors"
import {connectDB} from "./Config/db.js";
import foodRouter from "./Routes/foodRoutes.js";
import router from "./Routes/userRoutes.js";
import 'dotenv/config.js';

const app = express();
const port = 4000;

//use env also

//use middleware
app.use(express.json());
app.use(cors());

//connect db
connectDB();
// api endponts
app.use("/api/food",foodRouter)
app.use("/images", express.static("upload"));
app.use("/api/user",router);






app.get("/", (req, res) => {
    res.send("Hello, World!");
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});



