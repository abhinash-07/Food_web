import { useState, useContext } from 'react';
import './LoginPop.css';
import { assets } from '../../assets/assets';
import { StoreContext } from '../../StoreContex/Storecontex';
import axios from 'axios';

const LoginPop = ({ setShowLogin }) => {
  const { url } = useContext(StoreContext);
  const { setToken } = useContext(StoreContext);
  const [currstate, setcurrstate] = useState("Login");
  const [data, setData] = useState({
    name: "",
    email: "",
    password: ""
  });

  const onChangeHandler = (event) => {
    const { name, value } = event.target;
    setData({ ...data, [name]: value });
  };

  const onLogin = async (event) => {
    event.preventDefault();
    let newurl = url;

    if (currstate === "Login") {
      newurl += "/api/user/login";
    } else {
      newurl += "/api/user/register";
    }

    console.log("API URL:", newurl);
    console.log("Payload:", data);

    try {
      const response = await axios.post(newurl, data);
      console.log(response);

      if (response.data.success) {
        setToken(response.data.token);
        localStorage.setItem("token", response.data.token);
        setShowLogin(false);
      } else {
        alert(response.data.message);
      }
    } catch (error) {
      console.error("Error during login:", error);
      alert(error.response?.data?.message || "Something went wrong. Please try again.");
    }
  };

  return (
    <div className="login-pop">
      <form onSubmit={onLogin} className="login-popup-container">
        <div className="login-popup-title">
          <h2>{currstate}</h2>
          <img onClick={() => setShowLogin(false)} src={assets.cross_icon} alt="close" />
        </div>
        <div className="login-popup-inputs">
          {currstate === "Login" ? (
            <>
              <input
                name="email"
                onChange={onChangeHandler}
                value={data.email}
                type="email"
                placeholder="Your email"
                required
              />
              <input
                name="password"
                onChange={onChangeHandler}
                value={data.password}
                type="password"
                placeholder="Your password"
                required
              />
            </>
          ) : (
            <>
              <input
                name="name"
                onChange={onChangeHandler}
                value={data.name}
                type="text"
                placeholder="Your name"
                required
              />
              <input
                name="email"
                onChange={onChangeHandler}
                value={data.email}
                type="email"
                placeholder="Your email"
                required
              />
              <input
                name="password"
                onChange={onChangeHandler}
                value={data.password}
                type="password"
                placeholder="Your password"
                required
              />
            </>
          )}
        </div>
        <button type="submit" className="login-popup-container">
          {currstate === "Sign Up" ? "Create Account" : "Login"}
        </button>
        {currstate === "Login" && (
          <div className="login-popup-forgot-password">
            <p>
              <span onClick={() => alert("Redirect to Forgot Password")}>Forgot Password?</span>
            </p>
          </div>
        )}
        <div className="login-popup-condition">
          <input type="checkbox" required />
          <p>By continuing, I agree to the terms & conditions and privacy policy.</p>
        </div>
        {currstate === "Login" ? (
          <p>
            Create a new account <span onClick={() => setcurrstate("Sign Up")}>Click here</span>
          </p>
        ) : (
          <p>
            Already have an account? <span onClick={() => setcurrstate("Login")}>Login Here</span>
          </p>
        )}
      </form>
    </div>
  );
};

export default LoginPop;
